package com.dsu.anu;

public class Recruitment {
	
	public void callCheckAge(int age)
	{
		try
		{
			checkAge(age);
		}
		catch(InvalidAgeException iae)
		{
			iae.printStackTrace();
		}
	}
	public void checkAge(int age) throws InvalidAgeException
	{
		System.out.println("We are Scrutinizing the age...");
		if(age >= 30 || age <= 20)
		{
		//	InvalidAgeException iae = new InvalidAgeException("Sorry Valid Age is 20-30");
			System.out.println("ERROR!!!!   Invalid Age is "+age);
		//	throw iae;
			// Anonymous Objects
			throw new InvalidAgeException("Sorry Valid Age is 20-30");
		}
		System.out.println("Valid Age "+age);
		System.out.println("Age Scrutiny Completed, can proceed with remaining Recruitment Process");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("We are In the Recruitment Process....");
		System.out.println("We are checking age .....");
		Recruitment rc = new Recruitment();
	/*	try
		{*/
			rc.callCheckAge(23);
			rc.callCheckAge(26);
			rc.callCheckAge(33);
			rc.callCheckAge(21);
			rc.callCheckAge(25);
	/*	}
		catch(InvalidAgeException iae)
		{
			System.out.println(iae.message);
			iae.printStackTrace();
		}*/
		System.out.println("We finished Recruitment Process");

	}

}
