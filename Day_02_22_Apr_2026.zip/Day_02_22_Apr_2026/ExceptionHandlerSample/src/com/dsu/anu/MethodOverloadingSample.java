package com.dsu.anu;

public class MethodOverloadingSample {

	double grossSalary;
	double nettSalary;
	public void calculateSalary(double basic,double hra,double cca,double allowance)
	{
		grossSalary = basic + hra + cca+allowance;
		System.out.println("The Gross Salary is "+grossSalary);
	}
	public void calculateSalary(double basic,double hra,double cca,double allowance,double deductions)
	{
		grossSalary = basic + hra + cca+allowance;
		nettSalary = grossSalary - deductions;
		System.out.println("The Gross Salary is "+grossSalary+" The Nett Salary is "+nettSalary);
	}
	public void calculateSalary(double basic,double hra,double cca,double allowance,double deductions,String empName)
	{
		grossSalary = basic + hra + cca+allowance;
		nettSalary = grossSalary - deductions;
		System.out.println("The Gross Salary is "+grossSalary+" The Nett Salary is "+nettSalary+" For Emplpoyee"+empName);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		MethodOverloadingSample mols = new MethodOverloadingSample();
		mols.calculateSalary(400, 250, 350, 200);
		mols.calculateSalary(300, 450, 250, 450, 350);
		mols.calculateSalary(450, 345, 245, 235,435,"Harsha");

	}

}
