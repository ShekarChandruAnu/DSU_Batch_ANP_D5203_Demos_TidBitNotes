package com.dsu.anu;

public class ArithmeticExceptionSample {
	public void calculate(int num1,int num2)
	{
		int result=0;
		System.out.println("In The Calculator Function....");
		try
		{
		result = num1 / num2;
		}
		catch(ArithmeticException ae)
		{
			ae.printStackTrace();
		//	System.out.println(ae.getMessage());
		}
		System.out.println("the Result is "+result);
		System.out.println("Exiting Calculator Function..");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ArithmeticExceptionSample aes = new ArithmeticExceptionSample();
		System.out.println("We are about to perform arith calculations");
	/*	try
		{*/
			aes.calculate(100, 25);
			aes.calculate(100, 50);
			aes.calculate(100, 0);
			aes.calculate(100, 2);
			aes.calculate(100, 10);
	/*	}
		catch(ArithmeticException ae)
		{
			ae.printStackTrace();
		//	System.out.println(ae.getMessage());
		}*/
		
		System.out.println("We finished arith calculations");
		

	}

}
