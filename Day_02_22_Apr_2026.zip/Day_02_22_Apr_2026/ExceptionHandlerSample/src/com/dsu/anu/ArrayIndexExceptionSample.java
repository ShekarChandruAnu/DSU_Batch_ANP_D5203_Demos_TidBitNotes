package com.dsu.anu;

public class ArrayIndexExceptionSample {

	public void manipulateArray()
	{
		int arr1[] = new int[10];
		System.out.println("Array Manipulation Started...");
		try
		{
			for(int i=0;i<=10;i++)
			{
				arr1[i] = (i+1)*10;
				System.out.println(arr1[i]);
			}
		}
		catch(ArrayIndexOutOfBoundsException aibe)
		{
			aibe.printStackTrace();
		}
		System.out.println("Array Manipulation Completed...");
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("We are about to manipulate Array....");
		ArrayIndexExceptionSample aes = new ArrayIndexExceptionSample();
	/*	try
		{*/
			aes.manipulateArray();
	/*	}
		catch(ArrayIndexOutOfBoundsException aie)
		{
			aie.printStackTrace();
		}*/
		System.out.println("We are out of Array Manipulation...");
	

	}

}
