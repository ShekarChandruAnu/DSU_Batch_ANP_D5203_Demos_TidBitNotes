package com.dsu.anu;

public class InvalidAgeException extends /*Throwable*/ Exception{
	String message;
	public InvalidAgeException(String message)
	{
		this.message = message;
	}

}
