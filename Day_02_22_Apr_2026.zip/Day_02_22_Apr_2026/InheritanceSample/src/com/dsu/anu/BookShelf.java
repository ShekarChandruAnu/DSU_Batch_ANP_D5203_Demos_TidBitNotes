package com.dsu.anu;

public class BookShelf extends Furniture{
	
	int noOfShelves;
	
	public void acceptBookShelfDetails()
	{
		
	}
	public void displayBookShelfDetails()
	{
		
	}

}
