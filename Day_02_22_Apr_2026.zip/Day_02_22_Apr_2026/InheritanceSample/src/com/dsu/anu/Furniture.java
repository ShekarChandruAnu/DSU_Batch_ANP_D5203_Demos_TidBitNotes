package com.dsu.anu;

import java.util.Scanner;

public class Furniture {

	int length;
	int width;
	int height;
	Scanner scan1;
	
	public Furniture()
	{
		scan1 = new Scanner(System.in);
	}
	
	public Furniture(int length, int width, int height, Scanner scan1) {
		super();
		this.length = length;
		this.width = width;
		this.height = height;
		this.scan1 = scan1;
	}
	
	public void acceptFurnitureDetails()
	{
		System.out.println("Enter the Furniture Details....");
		System.out.println("Enter the Length ");
		length = scan1.nextInt();
		
		System.out.println("Enter the Width");
		width = scan1.nextInt();
		
		System.out.println("Enter the Height");
		height = scan1.nextInt();
	}
	public void displayFurnitureDetails()
	{
		System.out.println("The Length is "+length);
		System.out.println("The Width is "+width);
		System.out.println("The Height is "+height);
	}
	
	
	
}
