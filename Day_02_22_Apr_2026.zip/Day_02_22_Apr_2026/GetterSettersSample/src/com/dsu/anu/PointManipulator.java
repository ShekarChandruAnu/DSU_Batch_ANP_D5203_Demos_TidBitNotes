package com.dsu.anu;

public class PointManipulator {
	public Point[]  generatePoints()
	{
		Point[] points = new Point[10];
		/*
		points[0] = new Point(10,20);
		points[1] = new Point();
		--
		--	
		points[9] = new Point();	
		*/
		for(int i=0;i<10;i++)
		{
			points[i] = new Point(i+10,i+20);
		}
		
		// return Point[] or Point[i] or Point or points[]
		return points;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PointManipulator pm = new PointManipulator();
		Point[] myPoints = pm.generatePoints();
		/* myPoints[0].displayCoordinates()
				myPoints[1] */
		
		for(int i=0;i<10;i++)
		{
			myPoints[i].displayCoordinates();
		}
		
	/*	Point x = new Point();
		x.displayData();*/

	}

}
