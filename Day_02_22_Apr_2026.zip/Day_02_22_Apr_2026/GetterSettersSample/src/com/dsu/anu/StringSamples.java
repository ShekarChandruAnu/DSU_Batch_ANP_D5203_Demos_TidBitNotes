package com.dsu.anu;

public class StringSamples {
	
	public void manipulateStrings()
	{
		String city = "Bangalore";
		System.out.println("City is "+city);
		city = "Hyderabad";
		System.out.println("New City is "+city);
		
		String city1 = "Hyderabad";
		System.out.println("city.equals(city1) "+city.equals(city1));
		System.out.println("city == city1 "+(city == city1));
		
		String myCity = new String("Mangalore");
		String myCity1 = new String("Mangalore");
		System.out.println("String as Object");
		System.out.println("myCity.equals(myCity) "+myCity.equals(myCity1));
		System.out.println("myCity1 == myCity1 "+(myCity == myCity1));
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StringSamples ssample = new StringSamples();
		ssample.manipulateStrings();

	}

}
