package com.dsu.anu;

public class ArraySample {
	
	public void manipulate1DArray()
	{
		int arr1[] = new int[10];
		for(int i=0;i<10;i++)
		{
			arr1[i]=(i+1) * 100;
			System.out.println("Element is "+arr1[i]);
		}
	}
	public void manipulate2DArray()
	{
		int arr2[][] = new int[3][2];
		for(int i=0;i<3;i++)
		{
			for(int j=0;j<2;j++)
			{
				arr2[i][j] = (i+j) * 10;
				System.out.print(arr2[i][j]+"  ");
			}
			System.out.println();
		}
	}
	public void manipulateJaggedArray()
	{
		int jagArr[][] = new int[3][];
		
		jagArr[0] = new int[5];
		jagArr[1] = new int[4];
		jagArr[2] =new int[3];
		
		for(int i=0;i<5;i++)
		{
			jagArr[0][i] = (i+0)* 10;
			System.out.print(jagArr[0][i]+" ");
		}
		System.out.println();
		for(int j=0;j<4;j++)
		{
			jagArr[1][j] = (j+0)* 100;
			System.out.print(jagArr[1][j]+" ");
		}
		System.out.println();
		for(int k=0;k<3;k++)
		{
			jagArr[2][k] = (k+0)* 1000;
			System.out.print(jagArr[2][k]+" ");
		}
		
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArraySample ars = new ArraySample();
		ars.manipulate1DArray();
		System.out.println("-------");
		ars.manipulate2DArray();
		ars.manipulateJaggedArray();

	}

}
