package com.dsu.anu;

public class VarArgsSample {
	
	public void add(int num1,int num2)
	{
		
	}
	public void calculateAverage(String studentName,String studentCourse,int... scores)
	{
		int total = 0;
		double averageScore;
		for(int i=0;i<scores.length;i++)
		{
			total = total +scores[i];
		}
		averageScore = total / scores.length ;
		System.out.println("Student Name "+studentName+" who has undertaken a course "+studentCourse+" Has the following scores");
		System.out.println("the average score "+averageScore);
	}
	
	public static void main(String[] args)
	{
		VarArgsSample vars = new VarArgsSample();
		vars.calculateAverage("Harsha", "MCA", 87,89,92,93);
		vars.calculateAverage("Harsha", "MCA", 87,89,92,93,67,72);
		vars.calculateAverage("Harsha", "MCA", 87,89,92);
		vars.calculateAverage("Harsha", "MCA", 87,89);
	}

}
