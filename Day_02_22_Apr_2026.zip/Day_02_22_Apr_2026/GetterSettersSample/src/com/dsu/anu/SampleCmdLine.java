package com.dsu.anu;

public class SampleCmdLine {
	
	
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			for(int i=0;i<args.length;i++)
			{
				System.out.println("The City is "+args[i]);
			}
	}

}
