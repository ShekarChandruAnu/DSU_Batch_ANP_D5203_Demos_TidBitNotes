package com.dsu.anu;

public class ArrayAddition {
	
	public int[][] addArrays(int[][] arr1,int[][] arr2)
	{
		int resultArr[][] = new int[2][2];
		for(int i=0;i<2;i++)
		{
			for(int j=0;j<2;j++)
			{
				resultArr[i][j] = arr1[i][j]+arr2[i][j];
			}
		}
		return resultArr;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ArrayAddition arad = new ArrayAddition();
		int arrx[][] = {{100,200},{300,400}};
		int arry[][] = {{10,20},{30,40}};
		int myResultArr[][] = arad.addArrays(arrx, arry);
		
		for(int i=0;i<2;i++)
		{
			for(int j=0;j<2;j++)
			{
				System.out.print(myResultArr[i][j]+" ");
			}
			System.out.println();
			
		}

	}

}
