package com.dsu.anu;

import java.util.StringTokenizer;

public class StringSample1 {

	public void manipulateString()
	{
		/*String address1 = "Rajajinagar";
		String address2 = "Rajajinagar";
		
		System.out.println("address1.equals(occupation2)  "+address1.equals(address2));
		System.out.println("address1 == occupation2 "+(address1 == address2) );
		
		String occupation1 = new String("Software ENGR"); 
		String occupation2 = new String("Software ENGR");
		
		System.out.println("occupation1.equals(occupation2)  "+occupation1.equals(occupation2));
		System.out.println("occupation1 == occupation2 "+(occupation1 == occupation2) );
		String str1 = "World is peaceful";
		
		
		String str2 = "And Beautiful";
		System.out.println("str1.length() : "+str1.length());
		System.out.println("str1.charAt(4)"+str1.charAt(4));
		System.out.println("str1.concat(occupation1)"+str1.concat(occupation1));
		
		String town1 = "Ramnagar";
		String town2 = "Ramanagar";
		System.out.println(town1.compareTo(town2));
		System.out.println(town2.compareTo(town1));
		
		System.out.println("-----------");
		String town3 = "Rama";
		String town4 = "Rama";
		System.out.println(town3.compareTo(town4));
		System.out.println(town3.compareTo(town4));
		
		System.out.println("--------");
		StringBuilder sbldr1 = new StringBuilder("World is beautiful ");
		sbldr1.append(" ANd also Peaceful");
		System.out.println("String Builder after appending "+sbldr1);
		
		StringBuffer sbfr1 = new StringBuffer("World is beautiful ");
		sbfr1.append(" ANd also Peaceful");
		System.out.println("String Buffer after appending "+sbfr1);
		
		sbfr1.insert(18, "Sometimes not Peaceful ");
		System.out.println(sbfr1);*/
		
		StringTokenizer strToken = new StringTokenizer("World:Is:Beautiful",":");
		while(strToken.hasMoreElements())
		{
			System.out.println(strToken.nextElement());
		}
		StringTokenizer strToken1 = new StringTokenizer("World:Is:Beautiful",":");
		while(strToken1.hasMoreTokens())
		{
			System.out.println(strToken1.nextToken());
		}
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		StringSample1 ss1 = new StringSample1();
		ss1.manipulateString();
	}

}
