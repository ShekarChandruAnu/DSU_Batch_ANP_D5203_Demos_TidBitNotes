package com.dsu.anu;
class SecondEmployee
{
	public void accessData()
	{
		Employee emp1 = new Employee();
		emp1.setEmpCode("E001");
		System.out.println("Employee Code is "+emp1.getEmpCode());
		System.out.println("Employee Code is "+emp1.getEmpCode());
		
	}
	
	
	
}

public class Employee {
	
	private String empCode;
	private String empName;
	private String empAddress;
	private String empPhone;
	private int empSalary;
	// ACCESS MODIFIERS: private public protected default
	public Employee()
	{
		this.empCode = "E001";
		this.empName = "Harsha";
		this.empAddress = "RTNagar";
		this.empPhone = "9839393993";
		this.empSalary=10000;
	}
	
	public void setEmpCode(String empCode)
	{
		this.empCode = empCode;
	}
	public String getEmpCode()
	{
		return this.empCode;
	}
	
	public void setEmpSalary(int empSalary)
	{
		this.empSalary = empSalary;
	}
	public int getempSalary()
	{
		return this.empSalary;
	}
	

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public String getEmpAddress() {
		return empAddress;
	}

	public void setEmpAddress(String empAddress) {
		this.empAddress = empAddress;
	}

	public String getEmpPhone() {
		return empPhone;
	}

	public void setEmpPhone(String empPhone) {
		this.empPhone = empPhone;
	}

	public Employee(String empCode, String empName, String empAddress, String empPhone, int empSalary) {
		super();
		this.empCode = empCode;
		this.empName = empName;
		this.empAddress = empAddress;
		this.empPhone = empPhone;
		this.empSalary = empSalary;
	}

	
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Employee gagan = new Employee();
		gagan.empAddress = "RTNagar";
		
		

	}

}
