package com.dsu.anu;
// Object Class System java.lang
public class Point {

	//System.out.prinltn()

	int xCoord, yCoord;
	
	public Point() {
		super();
		
	}/**/
	// this
	public Point(int xCoord, int yCoord) {
		super();
		this.xCoord = xCoord;
		this.yCoord = yCoord;
	}
	
	public void displayCoordinates()
	{
		System.out.println("The X Coordinate is "+xCoord+" Y Coordinate is "+yCoord);
		
	}
	public void displayData()
	{
		System.out.println("Displaying");
	}
	
	
}
