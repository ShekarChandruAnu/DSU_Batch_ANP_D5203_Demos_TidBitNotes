package com.dsu.anu;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class SerializerSample {

	ObjectOutputStream ops ;
	
	public void serializeObjects()
	{
		try {
			ops = new ObjectOutputStream(new FileOutputStream("employees.txt"));
			Employee emp1 = new Employee("E001","Harsha","RTNagar",10000,12.34f);
			ops.writeObject(emp1);
			ops.flush();
			ops.close();
			System.out.println("Objects Serialized Successfully...");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SerializerSample sSamp = new SerializerSample();
		sSamp.serializeObjects();

	}

}
