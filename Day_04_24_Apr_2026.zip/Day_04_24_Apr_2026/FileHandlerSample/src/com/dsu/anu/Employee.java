package com.dsu.anu;

import java.io.Serializable;

public class Employee implements Serializable{
	
	String empId;
	String empName;
	String empAddress;
	int empSalary;
	float incomeTax;
	
	public Employee() {
		super();
	}

	// Constructor OverloadedConstructor Getters/Setters toString()
	public Employee(String empId, String empName, String empAddress, int empSalary, float incomeTax) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.empAddress = empAddress;
		this.empSalary = empSalary;
		this.incomeTax = incomeTax;
	}

	public String getEmpId() {
		return empId;
	}

	public void setEmpId(String empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public String getEmpAddress() {
		return empAddress;
	}

	public void setEmpAddress(String empAddress) {
		this.empAddress = empAddress;
	}

	public int getEmpSalary() {
		return empSalary;
	}

	public void setEmpSalary(int empSalary) {
		this.empSalary = empSalary;
	}

	public float getIncomeTax() {
		return incomeTax;
	}

	public void setIncomeTax(float incomeTax) {
		this.incomeTax = incomeTax;
	}

	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName + ", empAddress=" + empAddress + ", empSalary="
				+ empSalary + ", incomeTax=" + incomeTax + "]";
	}/* */
	

	
}
