package com.dsu.anu;

import java.io.FileWriter;
import java.io.IOException;

public class FileWriterSample {

	FileWriter fw;
	String str = "We are writing to Character Stream...";
	public void writeToCharStream()
	{
		try {
			fw = new FileWriter("dealer.txt");
			fw.write(str);
			fw.flush();
			fw.close();
			System.out.println("We wrote data successfully..");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		FileWriterSample fws = new FileWriterSample();
		fws.writeToCharStream();

	}

}
