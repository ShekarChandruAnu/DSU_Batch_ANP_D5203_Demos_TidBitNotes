package com.dsu.anu;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;

public class DeSerializerSample {

	ObjectInputStream ois;
	public void deSerializeObjects()
	{
		try {
			ois = new ObjectInputStream(new FileInputStream("employees.txt"));
			Employee employee = (Employee)ois.readObject();
			System.out.println(employee);
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch(ClassNotFoundException cnfe)
		{
			cnfe.printStackTrace();
		}
		
	}
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DeSerializerSample dss = new DeSerializerSample();
		dss.deSerializeObjects();

	}

}
