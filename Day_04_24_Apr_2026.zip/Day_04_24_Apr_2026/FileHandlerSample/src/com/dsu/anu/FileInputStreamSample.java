package com.dsu.anu;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class FileInputStreamSample {

	FileInputStream fis;
	byte[] myBytes = new byte[100];
	public void readFromBinaryStream()
	{
		try {
			fis = new FileInputStream("customer.txt");
			fis.read(myBytes);
			String dataRead = new String(myBytes);
			System.out.println("Data Read from File is "+dataRead);
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch(IOException ioe)
		{
			ioe.printStackTrace();
		}
	}
		public static void main(String[] args) {
		// TODO Auto-generated method stub
		FileInputStreamSample fiss = new FileInputStreamSample();
		fiss.readFromBinaryStream();

	}

}
