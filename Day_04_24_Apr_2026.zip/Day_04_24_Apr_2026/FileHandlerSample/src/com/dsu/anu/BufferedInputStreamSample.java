package com.dsu.anu;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class BufferedInputStreamSample {
	
	BufferedInputStream bis;
	byte[] mybytes = new byte[100];
	public void readFromBinaryThroughBuffer()
	{
		try {
			bis = new BufferedInputStream(new FileInputStream("supplier.txt"));
			bis.read(mybytes);
			String readBytes = new String(mybytes);
			System.out.println("Data Read "+readBytes);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch(IOException ioe)
		{
			ioe.printStackTrace();
		}
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BufferedInputStreamSample bits = new BufferedInputStreamSample();
		bits.readFromBinaryThroughBuffer();

	}

}
