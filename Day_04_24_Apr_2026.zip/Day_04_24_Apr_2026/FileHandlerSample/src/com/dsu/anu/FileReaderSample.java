package com.dsu.anu;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class FileReaderSample {

	FileReader fr;
	int chars;
	public void readFromCharStream()
	{
		try {
			fr = new FileReader("dealer.txt");
			System.out.println("Data Read from file");
			while ((chars = fr.read()) != -1)
			{
				System.out.print((char)chars);
			}
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch(IOException ioe)
		{
			ioe.printStackTrace();
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		FileReaderSample frs = new FileReaderSample();
		frs.readFromCharStream();

	}

}
