package com.dsu.anu;

public class Student {
	
	String studId;
	String studName;
	String studCourse;
	
	

	public Student() {
		super();
	}



	public Student(String studId, String studName, String studCourse) {
		super();
		this.studId = studId;
		this.studName = studName;
		this.studCourse = studCourse;
	}
	


	@Override
	public String toString() {
		return "Student [studId=" + studId + ", studName=" + studName + ", studCourse=" + studCourse + "]";
	}



	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student student1 = new Student("S001","Harsha","MCA");
		System.out.println(student1);

	}

}
