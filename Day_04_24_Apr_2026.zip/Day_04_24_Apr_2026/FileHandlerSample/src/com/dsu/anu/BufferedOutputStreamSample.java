package com.dsu.anu;

import java.io.BufferedOutputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class BufferedOutputStreamSample {
	
	BufferedOutputStream bos;
	String str = "We are writing some data to Binary stream through Buffer";
	byte[] mybytes = new byte[100];
	public void writeToBinaryThroughBuffer()
	{
		try {
			 /*FileOutputStream fos = new FileOutputStream("supplier.txt");
			bos = new BufferedOutputStream(fos);*/
			mybytes = str.getBytes();
			//bos = new BufferedOutputStream(new FileOutputStream("supplier.txt"),1000000);
			bos = new BufferedOutputStream(new FileOutputStream("supplier.txt"));
			bos.write(mybytes);
			bos.flush();
			bos.close();
			System.out.println("We wrote successfully to binary stream thru buffer");
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch(IOException ioe)
		{
			ioe.printStackTrace();
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BufferedOutputStreamSample bss = new BufferedOutputStreamSample();
		bss.writeToBinaryThroughBuffer();

	}

}
