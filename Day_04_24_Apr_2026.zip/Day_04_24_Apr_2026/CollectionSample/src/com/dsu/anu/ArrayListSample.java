package com.dsu.anu;

import java.util.ArrayList;

public class ArrayListSample {

	public void manipulateArrayList()
	{
		ArrayList myList = new ArrayList();
		myList.add("Hello World");
		myList.add(1000);
		myList.add(1234.5678);
		myList.add(9848949499499L);
		myList.add(true);
		
		for(Object object:myList)
		{
			System.out.println("The Element in List is "+object);
		}
	
		/*
		int arr[] = {10,20,30,40,50};
		
		for(int x : arr)
		{
			System.out.println(x);
		}*/
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayListSample als = new ArrayListSample();
		als.manipulateArrayList();

	}

}
