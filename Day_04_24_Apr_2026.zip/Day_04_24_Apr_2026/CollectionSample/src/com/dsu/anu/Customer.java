package com.dsu.anu;

public class Customer {
	
	String custId;
	String custName;
	String custAddress;
	String custPhone;
	int purchaseValue;
	
	public Customer() {
		super();
	}

	public Customer(String custId, String custName, String custAddress, String custPhone, int purchaseValue) {
		super();
		this.custId = custId;
		this.custName = custName;
		this.custAddress = custAddress;
		this.custPhone = custPhone;
		this.purchaseValue = purchaseValue;
	}

	public String getCustId() {
		return custId;
	}

	public void setCustId(String custId) {
		this.custId = custId;
	}

	public String getCustName() {
		return custName;
	}

	public void setCustName(String custName) {
		this.custName = custName;
	}

	public String getCustAddress() {
		return custAddress;
	}

	public void setCustAddress(String custAddress) {
		this.custAddress = custAddress;
	}

	public String getCustPhone() {
		return custPhone;
	}

	public void setCustPhone(String custPhone) {
		this.custPhone = custPhone;
	}

	public int getPurchaseValue() {
		return purchaseValue;
	}

	public void setPurchaseValue(int purchaseValue) {
		this.purchaseValue = purchaseValue;
	}

	@Override
	public String toString() {
		return "Customer [custId=" + custId + ", custName=" + custName + ", custAddress=" + custAddress + ", custPhone="
				+ custPhone + ", purchaseValue=" + purchaseValue + "]";
	}

 /*	@Override
	public String toString() {
	String str = "Customer "+custName+"  With an Id "+custId+"Residing at "+custAddress+" has a Contact "+custPhone+"Has Purchased Goods worth"+purchaseValue;
	return str;
	}*/
	/**/
	
	

}
