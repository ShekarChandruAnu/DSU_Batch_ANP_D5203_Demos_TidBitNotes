package com.dsu.anu;

import java.util.Iterator;
import java.util.LinkedList;

public class LinkedListSample {

	LinkedList <Customer> customersLL = new LinkedList<Customer>();
	public void populateLinkedList()
	{
		Customer c1 = new Customer("C001","Harsha","RTNagar","8595995959",1000);
		customersLL.add(c1);
	
		customersLL.addFirst(new Customer("C001a","Suresh Kumar","Jayanagar","7388388383",2000));
		customersLL.add(new Customer("C002","Kiran Kumar","Jayanagar","7388568383",2000));
		customersLL.add(new Customer("C003","Rajesh","ViJayanagar","7345388383",2000));
		customersLL.add(new Customer("C004","Rajan Kumar","Malleswaram","7878388383",3000));
		customersLL.add(new Customer("C005","Mohan Kumar","Koramangala","7386588383",4000));
		customersLL.add(new Customer("C006","Keerthana","Indiranagar","7388354383",5000));
		customersLL.addLast(new Customer("C006a","Sumanth Kumar","ViJayanagar","7458388383",2000));
	}
	public void fetchLinkedListUsingIterator()
	{
		Customer customerAt4 = customersLL.get(4);
		
		System.out.println("Customer at index 4 "+customerAt4);
		
		Iterator <Customer> custLLIter = customersLL.iterator();
		while(custLLIter.hasNext())
		{
			Customer customer = custLLIter.next();
			System.out.println(customer);
		}
		customersLL.remove(3);
		System.out.println("After Removal...");
		Iterator <Customer> custLLIter1 = customersLL.iterator();
		while(custLLIter1.hasNext())
		{
			Customer customer = custLLIter1.next();
			System.out.println(customer);
		}
	}
	public void fetchLinkedListUsingDescIterator()
	{
		Iterator <Customer> custLLDescIter = customersLL.descendingIterator();
		while(custLLDescIter.hasNext())
		{
			Customer customer = custLLDescIter.next();
			System.out.println(customer);
		}
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LinkedListSample lls = new LinkedListSample();
		lls.populateLinkedList();
		lls.fetchLinkedListUsingIterator();
		System.out.println("------- In Desc Order");
		lls.fetchLinkedListUsingDescIterator();
		
		

	}

}
