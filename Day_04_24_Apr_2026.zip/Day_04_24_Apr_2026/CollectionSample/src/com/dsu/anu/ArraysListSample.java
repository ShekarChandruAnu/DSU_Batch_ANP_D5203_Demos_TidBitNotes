package com.dsu.anu;

import java.util.ArrayList;
import java.util.Iterator;

public class ArraysListSample {
	
	ArrayList <Customer> customersList = new ArrayList<Customer>();
	
	public void populateArrayList()
	{
		Customer c1 = new Customer("C001","Harsha","RTNagar","8595995959",1000);
		customersList.add(c1);
	
		
		customersList.add(new Customer("C002","Kiran Kumar","Jayanagar","7388388383",2000));
		customersList.add(new Customer("C003","Rajesh","ViJayanagar","7345388383",2000));
		customersList.add(new Customer("C004","Rajan Kumar","Malleswaram","7878388383",3000));
		customersList.add(new Customer("C005","Mohan Kumar","Koramangala","7386588383",4000));
		customersList.add(new Customer("C006","Keerthana","Indiranagar","7388354383",5000));
		
	}
	// 3 ways to fetch data out of ARRAYLIST
	public void fetchArrayListDataUsingForEach()	
	{
		System.out.println("The Customers are...");
		for(Customer customer:customersList)
		{
			System.out.println(customer);
		}
	}
	public void fetchArrayListUsingIterator()
	{
		System.out.println("Customers are....");
		Iterator <Customer> custIter = customersList.iterator();
		while(custIter.hasNext())
		{
			Customer cust = custIter.next();
			System.out.println(cust);
		}
	}
	public void displayUsingCollection()
	{
		System.out.println(customersList);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArraysListSample als = new ArraysListSample();
		als.populateArrayList();
		als.fetchArrayListDataUsingForEach();
		System.out.println("----ITERATOR ----");
		als.fetchArrayListUsingIterator();
		System.out.println("-----DIRECT COLLN-------");
		als.displayUsingCollection();
		

	}

}
