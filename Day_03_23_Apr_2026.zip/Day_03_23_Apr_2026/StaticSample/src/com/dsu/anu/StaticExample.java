package com.dsu.anu;

public class StaticExample {

	int nonStaticVar;
	static int staticVar;
	// Static Method can access only static variables
	//Non static methods can access both static & nonstatic variables
	public static void staticMethod1()
	{
		staticVar++;
		System.out.println("The Static Var in StaticMethod 1   is :"+staticVar);
	}
	public void nonStaticMethod1()
	{
		staticVar++;
		nonStaticVar++;
		System.out.println("The Static Var in NonStaticMethod 1   is :"+staticVar);
		System.out.println("The Non Static Var in NonStaticMethod 1   is :"+nonStaticVar);
	}
	public static void staticMethod2()
	{
		staticVar++;
		System.out.println("The Static Var in StaticMethod 2   is :"+staticVar);
	}
	public void nonStaticMethod2()
	{
		staticVar++;
		nonStaticVar++;
		System.out.println("The Static Var in NonStaticMethod 2   is :"+staticVar);
		System.out.println("The Non Static Var in NonStaticMethod 2   is :"+nonStaticVar);
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StaticExample stamp1 = new StaticExample();
		StaticExample.staticMethod1(); // statvar: 1
		stamp1.nonStaticMethod1(); //staticVar : 2     nonStaticVar: 1
		stamp1.nonStaticMethod2(); //staticVar : 3	   nonStaticVar : b 2  a 1
		
		StaticExample stamp2 = new StaticExample();
		StaticExample.staticMethod2(); //staticVar : 4
		stamp2.nonStaticMethod1(); //staticVar :5   nonStaticVar: a 1    b 3
		stamp2.nonStaticMethod2();// staticVar : 6   nonStaticVar : a 1  b 4
		

	}

}
