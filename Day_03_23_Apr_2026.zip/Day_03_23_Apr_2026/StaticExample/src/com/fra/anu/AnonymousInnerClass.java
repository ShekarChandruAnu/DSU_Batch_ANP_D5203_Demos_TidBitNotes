package com.fra.anu;
class Shapes
{
	public void display()
	{
		System.out.println("Displaying SHapes");
	}
}
class Rectangle extends Shapes
{
	
	
}
class Triangle extends Shapes
{
	
}
public class AnonymousInnerClass {

	int score = 85;
	static int grace = 5;
	//static employee e1 = new Employee() { jksaldjlakdj };
	static Shapes rectangle = new Shapes() {
		//Overriding the method of a Class
		public void display()
		{
			System.out.println("Displaying Rectangles..");
			System.out.println(grace);
			//System.out.println(score); //NOT ALLOWED TO ACCESS NON ST VAR
		}
	};
	/*
	 * static Shapes triangle = new Shapes() {
		//Overriding the method of a Class
		public void display()
		{
			System.out.println("Displaying Triangle..");
			System.out.println(grace);
			//System.out.println(score);
		}
	};
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		rectangle.display();
		//triangle.display()

	}

}
