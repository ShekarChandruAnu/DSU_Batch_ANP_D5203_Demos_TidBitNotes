package com.fra.anu;

public class StaticBlockSample {

	//static Block called only once
	//Non static Block called every time an instance is created
	int var1 = 100;
	static int var2 = 200;
	
	//non static block can access both static and non static variable
	{
		System.out.println("NON STATIC BLOCK INVOKED");
		System.out.println(" non static Var1 in non static block "+var1);
		System.out.println(" static Var2 in non static block "+var2);
	}
	
	static // static block can access only static variable
	{
		System.out.println("STATIC BLOCK INVOKED");
		System.out.println(" static Var2 in  static block "+var2);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*
		 * when an instance is created nonstatic block is called automatically
		 * but static block is called only once
		 */
		StaticBlockSample sbs1 = new StaticBlockSample();
		StaticBlockSample sbs2 = new StaticBlockSample();
		StaticBlockSample sbs3 = new StaticBlockSample();
		StaticBlockSample sbs4 = new StaticBlockSample();

	}

}
