package com.dsu.anu;

public interface Insurance {

	public void createPolicy();
	public void terminatePolicy();
	public void calculatePremium();
}
