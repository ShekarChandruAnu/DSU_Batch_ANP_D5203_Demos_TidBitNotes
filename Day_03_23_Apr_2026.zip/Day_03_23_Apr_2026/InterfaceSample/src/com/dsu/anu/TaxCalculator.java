package com.dsu.anu;

public class TaxCalculator {

	public void calculateTax()
	{
		System.out.println(" Tax Calculation is Under Process...");
	}
}
