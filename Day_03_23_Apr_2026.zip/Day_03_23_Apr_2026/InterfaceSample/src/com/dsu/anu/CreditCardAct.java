package com.dsu.anu;

public interface CreditCardAct {
	public void calculateOutstandingAmt();
	public void calculateRedemptionPoints();

}
