package com.dsu.anu;

public interface DebitCardAcct {

	public void checkBalance();
	public void depositAmt();
	public void withdrawAmt();
}
