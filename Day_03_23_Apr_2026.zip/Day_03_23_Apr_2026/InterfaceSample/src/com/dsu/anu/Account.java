package com.dsu.anu;

public interface Account extends CreditCardAct,DebitCardAcct{

	public void createAccount();
	public void closeAccount();
}
