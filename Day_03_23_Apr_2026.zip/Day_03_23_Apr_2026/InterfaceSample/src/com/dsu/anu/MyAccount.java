package com.dsu.anu;

public class MyAccount extends TaxCalculator implements Account,Insurance{

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MyAccount mac = new MyAccount();
		mac.createAccount();
		mac.createPolicy();
		mac.calculateRedemptionPoints();
		mac.calculateOutstandingAmt();
		mac.checkBalance();
		mac.depositAmt();
		mac.withdrawAmt();
		mac.calculatePremium();
		mac.terminatePolicy();
		mac.closeAccount();

	}

	@Override
	public void calculateOutstandingAmt() {
		// TODO Auto-generated method stub
		System.out.println("Outsanding AMt calculated...");
	}

	@Override
	public void calculateRedemptionPoints() {
		// TODO Auto-generated method stub
		System.out.println("Redemption Points Calculated...");
		
	}

	@Override
	public void checkBalance() {
		// TODO Auto-generated method stub
		System.out.println("Balance Check is in Process...");
		
	}

	@Override
	public void depositAmt() {
		// TODO Auto-generated method stub
		System.out.println("AMount Deposited successfully");
	}

	@Override
	public void withdrawAmt() {
		// TODO Auto-generated method stub
		System.out.println("Amt withdrawn successfully..");
		
	}

	@Override
	public void createPolicy() {
		// TODO Auto-generated method stub
		System.out.println("Policy is under Creation..");
		
	}

	@Override
	public void terminatePolicy() {
		// TODO Auto-generated method stub
		System.out.println("Policy is Requested for Termination...");
		
	}

	@Override
	public void calculatePremium() {
		// TODO Auto-generated method stub
		System.out.println("The Premium payable is ..");
		
	}

	@Override
	public void createAccount() {
		// TODO Auto-generated method stub
		System.out.println("Account Created ....");
		
		
	}

	@Override
	public void closeAccount() {
		// TODO Auto-generated method stub
		System.out.println("Account Requested for Closure...");
		
	}

}
