package com.dsu.anu;

public class XmlParser extends Parser{

	@Override
	public void parseFile(String filetype) {
		// TODO Auto-generated method stub
		System.out.println(filetype +" IS successfully Parsed...");
		
	}

	

}
