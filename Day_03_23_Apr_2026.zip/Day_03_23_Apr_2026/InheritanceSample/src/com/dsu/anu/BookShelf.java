package com.dsu.anu;

public class BookShelf extends Furniture{
	
	int noOfShelves;
	
	public void acceptBookShelfDetails()
	{
		/*System.out.println("Enter the Length ");
		length = scan1.nextInt();
		System.out.println("Enter the Width ");
		width = scan1.nextInt();
		System.out.println("Enter the Height");
		height = scan1.nextInt();*/
		super.acceptFurnitureDetails();
		System.out.println("Enter the No Of Shelves");
		noOfShelves = scan1.nextInt();
	}
	public void displayBookShelfDetails()
	{
		System.out.println("The Book SHelf Details...");
	/*	System.out.println("The Length is "+length);
		System.out.println("The Width is "+width);
		System.out.println("The Height is "+height);*/
		super.displayFurnitureDetails();
		System.out.println("The No Of Shelves is "+noOfShelves);
	}
	
	public static void main(String[] args)
	{
		Furniture furniture1 = new Furniture();
		System.out.println("Dealing with Only Furniture details");
		furniture1.acceptFurnitureDetails();
		furniture1.displayFurnitureDetails();
		
		System.out.println("Dealing with BookShelf  details");
		BookShelf shelf1 = new BookShelf();
		shelf1.acceptBookShelfDetails();
		shelf1.displayBookShelfDetails();
	}

}
