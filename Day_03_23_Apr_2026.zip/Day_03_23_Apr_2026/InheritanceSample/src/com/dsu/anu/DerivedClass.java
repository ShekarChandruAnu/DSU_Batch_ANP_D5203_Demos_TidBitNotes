package com.dsu.anu;

public class DerivedClass extends BaseClass{

	public void display2()
	{
		System.out.println("Displaying 2 of Base class");
	}
	
	@Override
	public void display()
	{
		System.out.println("Displaying the Derived Class..");
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DerivedClass dc  = new DerivedClass();
		dc.display1();
		dc.display2();
		BaseClass bc = new BaseClass();
				bc.display();
		dc.display();
		
		BaseClass bc1 = new DerivedClass();
		
		DerivedClass dcc = (DerivedClass) new BaseClass();
		
		
	}

}
