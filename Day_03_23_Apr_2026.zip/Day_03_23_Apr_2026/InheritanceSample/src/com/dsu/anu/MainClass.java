package com.dsu.anu;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Parser myParser ;
		myParser = new XmlParser();
		myParser.parseFile("XML File");
		
		myParser = new JsonParser();
		myParser.parseFile("JSON File");
		
		myParser = new PdfParser();
		myParser.parseFile("PDF File");
		

	}

}
