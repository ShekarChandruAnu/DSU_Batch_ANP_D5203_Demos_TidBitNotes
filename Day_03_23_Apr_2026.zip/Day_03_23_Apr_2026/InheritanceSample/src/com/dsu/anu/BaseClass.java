package com.dsu.anu;

public class BaseClass {
	
	public void display1()
	{
		System.out.println("Displaying 1 of Baseclass");
	}
	public void display()
	{
		System.out.println("Displaying Base Class Details..");
	}

}
