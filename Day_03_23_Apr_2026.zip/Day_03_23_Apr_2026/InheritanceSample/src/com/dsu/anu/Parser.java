package com.dsu.anu;

public abstract class Parser {

	public abstract void parseFile(String filetype);
	public void nonAbstractMethod()
	{
		System.out.println("Displaying Non Abstract Method Details...");
	}
}
