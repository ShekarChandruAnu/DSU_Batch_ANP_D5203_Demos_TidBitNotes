package com.dsu.anu;

public class JsonParser extends Parser {

	@Override
	public void parseFile(String filetype) {
		// TODO Auto-generated method stub
		System.out.println(filetype+" Parsed Successully");
		
	}

}
