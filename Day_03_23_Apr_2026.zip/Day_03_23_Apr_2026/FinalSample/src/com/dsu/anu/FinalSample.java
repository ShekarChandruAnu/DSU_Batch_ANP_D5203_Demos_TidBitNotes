package com.dsu.anu;
final class MyFinalClass
{
	public void methodInFinalClass()
	{
		
	}
}
class MyNonFinalClass
{
	public void methodInNonFinalClass()
	{
		
	}
	public final void finalMethodInNonFinalClass()
	{
		
	}
	
}
//public class FinalSample  extends MyNonFinalClass{ ALLOWED
//public class FinalSample  extends MyFinalClass{  NOT ALLOWED
	public class FinalSample extends MyNonFinalClass{
		
		@Override
		public void methodInNonFinalClass()
		{
			 final int GRACE_MARKS = 5;
			//  graceMarks+=3; NOT ALLOWED SINCE IT
		}
		 /*@Override NOT ALLOWED TO OVERRIDE FINAL METHOD 
		public  void finalMethodInNonFinalClass()
		{
			
		}*/
		
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
