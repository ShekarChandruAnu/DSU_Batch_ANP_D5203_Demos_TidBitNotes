package com.dsu.anu;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class FileStreamWriterSample {
	
	FileOutputStream fos;
	String str = "we are writing some data to binary file";
	byte[] mybytes = new byte[100];
	public void writeToBinaryStream()
	{
		
				try {
					fos = new FileOutputStream("customer.txt");
					mybytes = str.getBytes();
					fos.write(mybytes);
					System.out.println("We wrote the data to Binary stream successfully...");
					fos.flush();
					fos.close();
				} catch (FileNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}  catch(IOException ioe)
				{
					ioe.printStackTrace();
				}		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		FileStreamWriterSample fsws = new FileStreamWriterSample();
		fsws.writeToBinaryStream();

	}

}
