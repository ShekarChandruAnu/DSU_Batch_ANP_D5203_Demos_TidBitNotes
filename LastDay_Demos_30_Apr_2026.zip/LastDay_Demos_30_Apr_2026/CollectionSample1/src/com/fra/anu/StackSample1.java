package com.fra.anu;

import java.util.Iterator;
import java.util.Stack;

public class StackSample1 {

	Stack <String> myStack = new Stack<>();
	public void populateStackThruPush()
	{
		myStack.push("Ahmedabad");
		myStack.push("Bangalore");
		myStack.push("Cuttack");
		myStack.push("Dhanbad");
		myStack.push("Ernakulam");
	}
	public void populateStackThruAdd()
	{
		myStack.add("Ahmedabad");
		myStack.add("Bangalore");
		myStack.add("Cuttack");
		myStack.add("Dhanbad");
		myStack.add("Ernakulam");
	}
	public void fetchThroughPop()
	{
		while(myStack.isEmpty() == false)
		{
			System.out.println("The Popped Element :"+myStack.pop());
		}
	}
	public void fetchThruIterator()
	{
		Iterator <String> stackIter = myStack.iterator();
		while(stackIter.hasNext())
		{
			System.out.println("The Element in Stack "+stackIter.next());
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StackSample1 samp1 = new StackSample1();
		System.out.println("----------Push-Pop------------");
		samp1.populateStackThruPush();
		samp1.fetchThroughPop();
		System.out.println("----------Add-iterate------------");
		samp1.populateStackThruAdd();
		samp1.fetchThruIterator();

	}

}
