package com.fra.anu;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class ConnectionSample {

	String url;
	String user;
	String password;
	Connection con;
	Statement stmt;
	PreparedStatement pstmt;
	ResultSet rs;
	public void testConnection()
	{
		url = "jdbc:mysql://localhost:3306/stfrancis_db";
		user = "root";
		password = "MySQL_@123456";
		try {
			//LOAD THE DRIVER
			Class.forName("com.mysql.cj.jdbc.Driver");
			//ESTABLISH CONNECTION
			con = DriverManager.getConnection(url, user, password);
			//CREATE STMT OBJECT
			stmt = con.createStatement();
			//EXECUTE n HANDLE RESULT
			rs = stmt.executeQuery("select * from Movies");
			System.out.println("The Movies Details are...");
			System.out.println("Movie Id    :    Movie Category    :  MovieName  : Movie Collections");
			while(rs.next())
			{
				System.out.println(rs.getString(1)+" : "+rs.getString(2)+" : "+rs.getString(3)+" : "+rs.getString(4));
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}  catch(SQLException sqe)
		{
			sqe.printStackTrace();
		}
		
	}
	
	public void getMovieById(String movieId)
	{
		url = "jdbc:mysql://localhost:3306/stfrancis_db";
		user = "root";
		password = "MySQL_@123456";
		try {
			//LOAD THE DRIVER
			Class.forName("com.mysql.cj.jdbc.Driver");
			//ESTABLISH CONNECTION
			con = DriverManager.getConnection(url, user, password);
			//CREATE STMT OBJECT
			pstmt = con.prepareStatement("select * from Movies where MovieId = ? ");
			pstmt.setString(1, movieId);
			//EXECUTE n HANDLE RESULT
			rs = pstmt.executeQuery();
			rs.next();
			System.out.println(rs.getString(1)+" : "+rs.getString(2)+" : "+rs.getString(3)+" : "+rs.getString(4));
									
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}  catch(SQLException sqe)
		{
			sqe.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub 
		
		ConnectionSample csamp = new ConnectionSample();
		csamp.testConnection();
		System.out.println("Based on Parematerized query");
		csamp.getMovieById("M13");

	}

}
