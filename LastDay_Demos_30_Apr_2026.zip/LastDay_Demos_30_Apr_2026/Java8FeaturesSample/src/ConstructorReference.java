interface Messageable{  
    Message getMessage(String msg);  
}  
interface Messageable1
{
	void getMessage();
}

/*
 * Messageable msg1 = () -> {
 * 
 * };
 * 
 * Messageable msg2 = (String str) -> {
 * 
 * Message m = new Message();
 * 	return m;
 * 
 * };
 */
class Message{  
	Message()
	{
		System.out.println("Called Default Constructor...");
	}
    Message(String msg){  
        System.out.print(msg);  
    }  
    
}  
public class ConstructorReference {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 Messageable hello = Message::new;  
	        hello.getMessage("Hello");
	        Messageable1 hello1 = Message::new;
	        hello1.getMessage();
	        
	       
	}

}
