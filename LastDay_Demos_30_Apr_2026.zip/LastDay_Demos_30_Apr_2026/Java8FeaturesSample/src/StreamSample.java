import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class StreamSample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("-----------Printing the List Collected from a STREAM--------------");
		Stream <Integer> myStream = Stream.of(10,20,30,40,50,60,70,80,90,100);
		//collect : Terminal Operator
		List <Integer> myList = myStream.collect(Collectors.toList());
		
		System.out.println(myList);
		System.out.println("-----------Printing The List Collected from an Array of Inetegers--------------");
		//Stream Generated from an ARray Of Integers
		Stream <Integer> myStream1 = Stream.of(new Integer[] {100,200,300,400,500,600,700,800});
		
		List <Integer> myList1 = myStream1.collect(Collectors.toList());
		
		System.out.println(myList1);
		// List1 converted to parallelStream
		ArrayList <Integer> list1 = new ArrayList<Integer>();
		System.out.println("---------Printing the List Collected from a Parallel Stream of Integer type Objects-------------------");
		for(int i=0;i<100;i++)
		{
			list1.add(i);
		}
		//list1.parallelStream()
		Stream myIntParStream = list1.parallelStream();
		
		List <Integer> myIntList1 = (List<Integer>) myIntParStream.collect(Collectors.toList());
		
		System.out.println(myIntList1);
		
		//Collections.sort(suppliers, (s1,s2) -> {s1.getSupplierCity.compareTo(s2.getSupplierCity())}
		
		
		Stream myIntSeqStream = list1.stream();// Sequential
		List <Integer> myIntList2 = (List<Integer>) myIntSeqStream.collect(Collectors.toList());
		System.out.println(myIntList2);
		System.out.println("-------------------Products Accessed thru Streams-------------------");
		ArrayList <Product> products = new ArrayList<Product>();
		products.add(new Product("P001","Television",10000,67));
		products.add(new Product("P002","Refrigerator",18000,120));
		products.add(new Product("P003","AirConditioner",25000,75));
		products.add(new Product("P004","WashingMachine",19000,80));
		products.add(new Product("P005","DishWasher",25000,45));
		products.add(new Product("P006","StereoPlayer",8000,124));
		// CURRYING - CHAINING - FUNCTIONAL PROGRAMMING []
		// ls | more | tr -s
		//Stream().filter().map().count()
		
		// products.stream() ---->SEQUENTIAL or PARALLEL STREAM??????
		Stream <Product> myProductStream = products
											.stream()
											.filter(p -> p.prodPrice >= 18000 );
		
		myProductStream.forEach(product -> System.out.println("Product Id :" +product.productId+" Product Name "+product.productName+" Product Price "+product.prodPrice));
		//method System.out::println method reference
	
		/* Stream is consumed/operated upon/closed cannot reuse
		List <Product> myNewProducts = myProductStream.collect(Collectors.toList());
		System.out.println(myNewProducts);
		*/
	}

}
