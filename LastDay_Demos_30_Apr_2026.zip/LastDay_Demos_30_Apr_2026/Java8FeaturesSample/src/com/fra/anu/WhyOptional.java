package com.fra.anu;
import java.util.Optional;

public class WhyOptional {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	/*	String[] str = new String[10];  
        String lowercaseString = str[5].toLowerCase();  
        System.out.print(lowercaseString);  */
		  String[] str = new String[10];  
	        Optional<String> checkNull = Optional.ofNullable(str[5]);  
	        if(checkNull.isPresent()){  // check for value is present or not  
	            String lowercaseString = str[5].toLowerCase();  
	            System.out.print(lowercaseString);  
	        }else  
	            System.out.println("string value is not present");  
	}

}
