package com.fra.anu;
interface MyInterface11
{
	public void display();
}
interface MyInterface22
{
	public void calculate(int a, int b);
}
interface Customerr
{
	public void calculateInvoiceAmt(int qty,int price);
}

interface NewCustomerr
{
	public double calculateInvoice(int qty,int price);
}

interface SalesDataa
{
	public void calculateInvoice(int qty,int price,NewCustomerr nc);
}
public class FunctionalInterfaceSample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		MyInterface11 inter1 = () -> {
			
			System.out.println("Welcome to Functional Interfaces");
			System.out.println("And Implementations Through Lambda Expressions ");
		};
		
		MyInterface22 inter21 = (int a,int b) -> {
			
			int result = a + b;
			System.out.println("The sum is "+result);
		};
		
		MyInterface22 inter22 = (int a,int b) ->{
			 int result = a * b;
			 System.out.println("The Product is "+result);
		};

		
		inter1.display();
		inter21.calculate(100, 20);
		inter22.calculate(100,20);
		System.out.println("----------------------");
		Customerr customer1 = (int qty, int price) -> {
			
			int invoiceAmt = qty * price;
			if(invoiceAmt >= 10000)
			{
				System.out.println(" Invoice Amt is "+invoiceAmt+" Good Purchase..");
			}
			else
			{
				System.out.println(" Invoice Amt is "+invoiceAmt+" Moderate Purchase..");
			}
			
		};
		customer1.calculateInvoiceAmt(100, 120);
		customer1.calculateInvoiceAmt(100, 50);
		System.out.println("----------------------------");
		NewCustomerr nCustomer1 = (int qty, int price) -> {
			
			double invAmt = qty * price;
			double finalInvAmt = invAmt - (0.1 * invAmt);
			return finalInvAmt;
		};
		
		NewCustomerr nCustomer2 = (int qty,int price) ->{
			double invAmt = qty * price;
			double finalInvAmt = invAmt - (0.2 * invAmt);
			return finalInvAmt;
		};
		System.out.println("-------------------------------");
		double customer1InvAmt = nCustomer1.calculateInvoice(1000, 100);
		System.out.println("The Invoice Amount for First Customer "+customer1InvAmt);
		
		double customer2InvAmt = nCustomer2.calculateInvoice(1000, 100);
		System.out.println("The Invoice Amount for Second Customer "+customer2InvAmt);
		
		System.out.println("-------------------------------");
		SalesDataa sd1 = (int qty , int price, NewCustomerr nc) -> {
			
			double actInvoiceValue = qty * price;
			System.out.println("The Actual Invoice Value is "+actInvoiceValue);
			if(actInvoiceValue >= 100000)
			{
				System.out.println("Prime Customer");
			}
			else
			{
				System.out.println("Regular Customer ");
			}
			double discountedInvValue = nc.calculateInvoice(qty, price);
			System.out.println("The Discounted Invoice Value is "+discountedInvValue);
		};
		System.out.println("First Customer Details....");
		sd1.calculateInvoice(1000, 120, nCustomer1);
		System.out.println("Second Customer Details....");
		sd1.calculateInvoice(1000, 120, nCustomer2);
	}

}
