package com.fra.anu;
import java.util.function.Function;
import java.util.function.Predicate;

public class FilterProgrammerOperation {

	public void filterProgrammers()
	{
		//FUNCTION HOLD THE DEFN OF SOME METHOD   BOT USE LAMBDA EXPR
		Function <Programmer,String> getProgrammerName = p->p.getName();
		
		//PREDICATES CHECK SOME CONDITION AND RETURN TRUE/FALSE
		Predicate <Programmer> isFemaleProgrammer = p-> p.isFemale();
		
		//CURRYING/ CHAINING
		Programmer.programmers()
					.stream() // Sequential Stream of Programmer Objects generated from the List of Programmers
					// Method Reference using Class
					.filter(Programmer::isFemale) // INTERMEDIATE / TERMINAL System.out::println
					//Method Reference using Class
					.map(Programmer::getName) // INTERMEDIATE/ TERMINAL OPR
					// Method Reference using Object
					.forEach(System.out::println);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		FilterProgrammerOperation fpo = new FilterProgrammerOperation();
		fpo.filterProgrammers();

	}

}
